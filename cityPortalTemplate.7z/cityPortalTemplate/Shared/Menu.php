<header> 
    <div class="width">

        <h1><a href="/">city<strong>biz</strong></a></h1>

        <nav>

            <ul class="sf-menu dropdown">


                <li><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
                <li><a href=""><i class="fa fa-database"></i> News </a>
                    <ul>
                        <li><a href="#">Product One</a></li>
                        <li><a href="#">Product Two</a></li>
                        <li><a href="#">Product Three</a></li>
                    </ul>

                </li>
                <li><a href="News.php"><i class="fa fa-database"></i> Events </a>
                    <ul>
                        <li><a href="#">Product One</a></li>
                        <li><a href="#">Product Two</a></li>
                        <li><a href="#">Product Three</a></li>
                    </ul>

                </li>

                <li>

                    <a href="#"><i class="fa fa-database"></i> YelloPage</a>

                    <ul>
                        <li><a href="#">Product One</a></li>
                        <li><a href="#">Product Two</a></li>
                        <li><a href="#">Product Three</a></li>
                    </ul>

                </li>

                <li><a href="#"><i class="fa fa-info"></i> Personalities </a></li>
                
                <li><a href="#"><i class="fa fa-database"></i> Login </a></li>

            </ul>


            <div class="clear"></div>
        </nav>
    </div>

    <div class="clear"></div>


</header>

