<footer>
    <div class="footer-content width">
        <ul>
            <li><h4>Proin accumsan</h4></li>
            <li><a href="#">Rutrum nulla a ultrices</a></li>
            <li><a href="#">Blandit elementum</a></li>
        </ul>

        <ul>
            <li><h4>Condimentum</h4></li>
            <li><a href="#">Curabitur sit amet tellus</a></li>
            <li><a href="#">Morbi hendrerit libero </a></li>
 
        </ul>

        <ul>
            <li><h4>Suspendisse</h4></li>
            <li><a href="#">Morbi hendrerit libero </a></li>
            <li><a href="#">Proin placerat accumsan</a></li>
        </ul>

        <ul class="endfooter">
            <li><h4>Suspendisse</h4></li>
            <li>Integer mattis blandit turpis, quis rutrum est.
                
                </br>
                </br>
                <div class="social-icons">

                    <a href="#"><i class="fa fa-facebook fa-2x"></i></a>

                    <a href="#"><i class="fa fa-twitter fa-2x"></i></a>

                    <a href="#"><i class="fa fa-youtube fa-2x"></i></a>

                    <a href="#"><i class="fa fa-instagram fa-2x"></i></a>

                </div>

            </li>
        </ul>

        <div class="clear"></div>
    </div>
    <div class="footer-bottom">
        <p>&copy; Kotkapura 2017. <a href="#"> Template Design </a> by 0code0 </p>
    </div>
</footer>
