<?php
$siteBasePath = "/cityPortalTemplate";

?>
<link rel="stylesheet" href="<?php echo "$siteBasePath/Theme/css/reset.css"; ?>" type="text/css" />
<link rel="stylesheet" href="<?php echo "$siteBasePath/Theme/css/styles.css"; ?>" type="text/css" />
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">


<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<script type="text/javascript" src="<?php echo "$siteBasePath/Theme/js/jquery.js"; ?>"></script>
<script type="text/javascript" src="<?php echo "$siteBasePath/Theme/js/slider.js"; ?>"></script>
<script type="text/javascript" src="<?php echo "$siteBasePath/Theme/js/superfish.js"; ?>"></script>

<script type="text/javascript" src="<?php echo "$siteBasePath/Theme/js/custom.js"; ?>"></script>

<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />