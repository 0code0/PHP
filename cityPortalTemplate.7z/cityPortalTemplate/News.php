<!doctype html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title> News </title>
        <?php
        require_once "./Shared/AllIncludes.php";
        ?>

    </head>
    <body>
        <div id="container">

            <?php
            require_once './Shared/Menu.php';
            ?>
            <div id="intro">

                <div class="width">

                    <div class="intro-content">

                        <h2>Tristique sem vitae metus ornare </h2>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>

                        <p><a href="#" class="button button-slider"><i class="fa fa-gbp"></i> Lorem ipsum dolor</a>
                            <a href="#" class="button button-reversed button-slider"><i class="fa fa-info"></i> Consectetuer adipiscing</a></p>


                    </div>

                </div>


            </div>

            <div id="body" class="width">



                <section id="content" class="two-column with-right-sidebar">

                    <article>


                        <h2> News </h2>
                        <div class="article-info">Posted on <time datetime="2013-05-14">14 May</time> by <a href="#" rel="author">Joe Bloggs</a></div>

                        <p>Welcome to city, a free valid CSS3 &amp; HTML5 responsive web template from <a href="http://zypopwebtemplates.com/" title="ZyPOP">ZyPOP</a>. This template is completely <strong>free</strong> to use permitting a link remains back to  <a href="http://zypopwebtemplates.com/" title="ZyPOP">http://zypopwebtemplates.com/</a>.</p>

                        <p> Should you wish to use this template unbranded you can buy a template license from our website for 8.00 GBP, this will allow you remove all branding related to our site, for more information about this see below.</p>	

                        <p>The image in the header is in the public domain, downloaded from <a href="http://unsplash.com/">UnSplash</a></p>

                        <p>This template has been tested in:</p>



                    </article>

                    <article class="expanded">

                        <h2>Buy unbranded</h2>
                        <div class="article-info">Posted on <time datetime="2013-05-14">14 May</time> by <a href="#" rel="author">Joe Bloggs</a></div>


                        <p>Purchasing a template license for 8.00 GBP (at time of writing around 12 USD) gives you the right to remove any branding including links, logos and source tags relating to ZyPOP. As well as waiving the attribution requirement, your payment will also help us provide continued support for users as well as creating new web templates. Find out more about how to buy at the licensing page on our website which can be accessed at <a href="http://zypopwebtemplates.com/licensing" title="template license">http://zypopwebtemplates.com/licensing</a></p>

                        <h3>Lorem lipsum</h3>

                        <p>Morbi fermentum condimentum felis, commodo vestibulum sem mattis sed. Aliquam magna ante, mollis vitae tincidunt in, malesuada vitae turpis. Sed aliquam libero ut velit bibendum consectetur. Quisque sagittis, est in laoreet semper, enim dui consequat felis, faucibus ornare urna velit nec leo. Maecenas condimentum velit vitae est lobortis fermentum. In tristique sem vitae metus ornare luctus tempus nisl volutpat. Integer et est id nisi tempus pharetra sagittis et libero.</p>


                        <a href="#" class="button">Read more</a>
                        <a href="#" class="button button-reversed">Comments</a>
                    </article>
                </section>

                <aside class="sidebar big-sidebar right-sidebar">


                    <ul>	
                        <li>
                            <h4> New Category </h4>
                            <ul class="blocklist">
                                <li><a class="selected" href="index.html">Home Page</a></li>
                                <li><a href="examples.html">Style Examples</a></li>
                                <li><a href="three-column.html">Three column layout example</a></li>
                                <li><a href="#">Sed aliquam libero ut velit bibendum</a></li>
                                <li><a href="#">Maecenas condimentum velit vitae</a></li>
                            </ul>
                        </li>





                        <li>
                            <h4> Adds </h4>
                            <ul class="newslist">
                                <li>
                                    <p><span class="newslist-date">Jul 21</span>
                                        Quisque hendrerit lorem sit amet dui viverra dictum. Phasellus imperdiet magna sit amet arcu tristique ultricies ut in dui.</p>
                                </li>

                                <li>
                                    <p><span class="newslist-date">May 09</span>
                                        Mauris et felis semper, congue dui ac, iaculis ipsum. Fusce non rhoncus risus, quis luctus nisl. Donec vitae velit tincidunt, tincidunt felis eu, suscipit nibh. </p>

                                </li>
                            </ul>
                        </li>

                    </ul>

                </aside>
                <div class="clear"></div>
            </div>

            <?php
            require_once './Shared/Footer.php';
            ?>
        </div>
    </body>
</html>